import os,sys,json,subprocess
from pathlib import Path
root=Path('/home/pxchen/workspace/qwen3_a11y_20261101');mode=sys.argv[1];tag='qwen3_8b_a11y_pair_20261101'+('_'+mode if mode!='full' else '')
run=root/'experiments/trace_reachability_validation/raw/a11y_text'/tag
assert (run/'run_config.json').exists()
assert not (run/'host.pid').exists()
env=dict(os.environ,QWEN_RUN_TAG=tag,PYTHONUNBUFFERED='1',NO_PROXY='*',no_proxy='*')
with (run/'host.nohup.log').open('ab') as log:
 p=subprocess.Popen(['nohup','python3',str(root/'host_supervisor.py'),'--root',str(root)],env=env,cwd=root,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
(run/'host.pid').write_text(str(p.pid));print(tag,p.pid)
