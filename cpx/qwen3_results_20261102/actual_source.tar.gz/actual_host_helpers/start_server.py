import os,json,subprocess,time,signal,urllib.request
from pathlib import Path
root=Path('/home/pxchen/workspace/services/qwen3_8b_a11y_20261101');root.mkdir(exist_ok=True)
status=json.load(open('/home/pxchen/workspace/services/qwen3_8b_download_20261101/status.json'));assert status['status']=='COMPLETE'
op=urllib.request.build_opener(urllib.request.ProxyHandler({}))
old=Path('/home/pxchen/workspace/services/gui_owl_15_8b_gpu45_20261031/server.pid');pid=int(old.read_text())
if Path(f'/proc/{pid}/cmdline').exists():
 args=Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\0',b' ').decode()
 assert 'vllm.entrypoints.openai.api_server' in args and 'GUI-Owl-1.5-8B-Instruct' in args and '--port 18197' in args
 with op.open('http://127.0.0.1:18197/metrics',timeout=5) as r:
  lines=r.read().decode().splitlines()
  assert all(float(l.rsplit(' ',1)[1])==0 for l in lines if l.startswith(('vllm:num_requests_running{','vllm:num_requests_waiting{')))
 (root/'previous_service.json').write_text(json.dumps(dict(pid=pid,args=args)))
 os.kill(pid,signal.SIGTERM)
 for _ in range(45):
  q=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid','--format=csv,noheader'],text=True)
  if not any(u in q for u in ['GPU-d152c6a7-1dcf-0ff2-1802-80647045e446','GPU-4630f136-1e70-b954-b995-1f460998c448']):break
  time.sleep(1)
 else:raise RuntimeError('Previous service did not release own GPUs')
cmd=['/home/pxchen/workspace/services/minicpmo45_20260929/venv312/bin/python','-m','vllm.entrypoints.openai.api_server','--model','/home/pxchen/workspace/models/Qwen3-8B','--served-model-name','Qwen3-8B-A11Y','--host','0.0.0.0','--port','18198','--tensor-parallel-size','2','--dtype','bfloat16','--max-model-len','32768','--gpu-memory-utilization','0.90','--max-num-seqs','2','--max-num-batched-tokens','4096','--seed','42','--enforce-eager','--attention-backend','TRITON_ATTN','--cpu-offload-gb','0','--generation-config','vllm','--override-generation-config',json.dumps(dict(temperature=0,top_p=1,top_k=-1,max_new_tokens=2048,repetition_penalty=1))]
env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-d152c6a7-1dcf-0ff2-1802-80647045e446,GPU-4630f136-1e70-b954-b995-1f460998c448',NO_PROXY='*',no_proxy='*',HF_HUB_OFFLINE='1')
env.update(CUDA_HOME='/usr/local/cuda-12.6',TRITON_PTXAS_PATH='/usr/local/cuda-12.6/bin/ptxas',VLLM_USE_FLASHINFER_SAMPLER='0',VLLM_WORKER_MULTIPROC_METHOD='spawn',PYTHONUNBUFFERED='1');env['PATH']='/usr/local/cuda-12.6/bin:/home/pxchen/workspace/services/minicpmo45_20260929/venv312/bin:'+env['PATH']
with (root/'server.log').open('a') as log:p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
(root/'server.pid').write_text(str(p.pid));(root/'launch.json').write_text(json.dumps(dict(cmd=cmd,pid=p.pid,model_revision=status['revision'],gpu_uuids=env['CUDA_VISIBLE_DEVICES'],cpu_offload_gb=0,thinking='disabled in every request'),indent=2))
print(p.pid)
