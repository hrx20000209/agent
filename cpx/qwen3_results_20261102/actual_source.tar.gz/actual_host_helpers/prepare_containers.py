import subprocess,json,datetime
from pathlib import Path
root=Path('/home/pxchen/workspace/qwen3_a11y_20261101');trial='/home/pxchen/workspace/android_world_mai8b_20261024/official_guiowl_trial_20261101';source='pxchen-guiowl-official-20261101';image='pxchen-aw-initialized-a11y:20261101'
def run(args):return subprocess.check_output(args,text=True).strip()
state=json.loads(run(['docker','inspect',source]))[0]
ps=run(['docker','exec',source,'ps','-eo','args']);assert 'run_ma35.py' not in ps and 'episode_entry.py' not in ps
run(['docker','stop','-t','30',source]);iid=run(['docker','commit',source,image]);records={}
for arm in ['BASE','FULL45']:
 name='pxchen-qwen3-a11y-'+arm.lower()+'-20261101'
 cmd=['docker','run','-d','--name',name,'--label','cpx.qwen3-a11y=20261101','--memory','12g','--cpus','4','--shm-size','2g','--device','/dev/kvm','-e','NO_PROXY=*','-e','no_proxy=*','-e','PYTHONPATH=/androidworld','-v',trial+':/official_trial:ro','-v',str(root)+':/androidworld','-w','/androidworld',image]+state['Config']['Cmd']
 cid=run(cmd);records[arm]=dict(name=name,id=cid,command=cmd)
(root/'container_provenance.json').write_text(json.dumps(dict(source_container=source,image=iid,source_was_finished=True,same_initialized_state=True,independent_writable_avds=True,records=records,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2))
print(json.dumps(records))
