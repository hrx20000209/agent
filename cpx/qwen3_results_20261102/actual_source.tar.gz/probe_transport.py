import sys,json
sys.path.insert(0,'/androidworld')
from android_world.env import env_launcher,android_world_controller
from a11y_transport import connect
print('LOAD',flush=True)
e=env_launcher.load_and_setup_env(adb_path='/opt/android/platform-tools/adb',freeze_datetime=False)
print('CONNECT',flush=True);p=connect(e);print('CONNECTED_PORT',p,flush=True)
s=e.get_state(wait_to_stabilize=False);print('FOREST_NODES',sum(len(w.tree.nodes) for w in s.forest.windows),flush=True);e.close()
