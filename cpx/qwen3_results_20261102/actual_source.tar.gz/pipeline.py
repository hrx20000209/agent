"""Nohup gate: both devices initialized -> paired smoke -> fresh full116 only if passed."""
import os,subprocess,json,time,concurrent.futures,datetime,traceback,sys
from pathlib import Path
ROOT=Path('/home/pxchen/workspace/qwen3_a11y_20261101');STATUS=ROOT/'pipeline.status.json'
def status(stage,**kw):
 temp=STATUS.with_suffix('.tmp');temp.write_text(json.dumps(dict(stage=stage,updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),**kw),indent=2));os.replace(temp,STATUS)
def initialize(arm):
 p=ROOT/'initialization'/arm;p.mkdir(parents=True,exist_ok=True)
 with (p/'nohup.log').open('ab') as log:
  rc=subprocess.call(['docker','exec','-e','FULL_ARM='+arm,'pxchen-qwen3-a11y-'+arm.lower()+'-20261101','/official_trial/runtime/bin/python','-u','/androidworld/initialize_a11y_device.py'],stdout=log,stderr=subprocess.STDOUT)
 proof=json.load(open(p/'report.json'));assert rc==0 and proof['verified'] and len(proof['apps'])==24,(arm,rc,proof.get('error'))
 return arm
def stage(mode):
 subprocess.run(['python3','/tmp/prepare_run.py',mode],check=True);subprocess.run(['python3','/tmp/launch_stage.py',mode],check=True)
 return ROOT/'experiments/trace_reachability_validation/raw/a11y_text'/('qwen3_8b_a11y_pair_20261101'+('_'+mode if mode!='full' else ''))
try:
 status('INITIALIZING_BOTH_DEVICES')
 with concurrent.futures.ThreadPoolExecutor(2) as pool:list(pool.map(initialize,['BASE','FULL45']))
 status('INITIALIZATION_VERIFIED_STARTING_SMOKE')
 smoke=stage('smoke3');status('PAIRED_SMOKE_RUNNING',run=str(smoke))
 for _ in range(180):
  if (smoke/'final_audit.json').exists():break
  time.sleep(10)
 else:raise RuntimeError('Smoke gate timed out after30min')
 for arm in ['BASE','FULL45']:
  rows=[json.loads(l) for l in (smoke/(arm+'.runs.jsonl')).read_text().splitlines()]
  assert len(rows)==2 and all(r.get('success')==1 and not r.get('error') and not r.get('rc') for r in rows),(arm,rows)
  for task in ['MarkorCreateNote','NotesIsTodo']:
   ep=smoke/arm/task/'p0';meta=json.load(open(ep/'meta.json'));assert meta['images_to_model']==0 and meta['thinking']==False
   reqs=[json.loads(l) for l in (ep/'a11y_requests.jsonl').read_text().splitlines()];assert reqs
   assert all(x['images']==0 and all(isinstance(m['content'],str) for m in x['request']['messages']) and x['request']['chat_template_kwargs']['enable_thinking']==False for x in reqs)
   if arm=='FULL45':assert meta['exploration_enabled'] and (ep/'windows.jsonl').exists()
 for task in ['MarkorCreateNote','NotesIsTodo']:
  a=json.load(open(smoke/'BASE'/task/'p0/meta.json'));b=json.load(open(smoke/'FULL45'/task/'p0/meta.json'));assert a['params']==b['params'] and a['seed']==b['seed']
 status('SMOKE_PASSED_STARTING_FORMAL',smoke=str(smoke))
 formal=stage('full');status('FORMAL116_LAUNCHED',run=str(formal),smoke=str(smoke),note='Independent BASE/FULL45 containers; fresh formal graph; no smoke results reused')
except BaseException as e:
 status('STOPPED_BEFORE_FORMAL' if not (ROOT/'experiments/trace_reachability_validation/raw/a11y_text/qwen3_8b_a11y_pair_20261101/host.pid').exists() else 'PIPELINE_ERROR',error=repr(e));traceback.print_exc();sys.exit(1)
