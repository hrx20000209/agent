"""Infrastructure gate: logical/model failures remain failures and do not change settings."""
import json,subprocess,time,os,datetime
from pathlib import Path
root=Path('/home/pxchen/workspace/qwen3_a11y_20261101');smoke=root/'experiments/trace_reachability_validation/raw/a11y_text/qwen3_8b_a11y_pair_20261101_smoke4'
for _ in range(180):
 if (smoke/'final_audit.json').exists():break
 time.sleep(5)
else:raise RuntimeError('Smoke supervisor did not finish')
proof=dict(smoke=str(smoke),model_success_required=False,note='Model mistakes (including disabled-target no-actions) are preserved. Gate checks complete episodes, valid actions, matching settings, budgets, images0 and graph/exploration configuration.',arms={},verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
for arm in ['BASE','FULL45']:
 rows=[json.loads(l) for l in (smoke/(arm+'.runs.jsonl')).read_text().splitlines()]
 assert len(rows)==2 and all(not r.get('error') and not r.get('rc') and not r.get('teardown_error') and 0<r['model_calls']<=r['allocated_budget'] for r in rows),(arm,rows)
 proof['arms'][arm]=rows
 for task in ['MarkorCreateNote','NotesIsTodo']:
  ep=smoke/arm/task/'p0';meta=json.load(open(ep/'meta.json'));assert meta['images_to_model']==0 and meta['thinking']==False
  reqs=[json.loads(l) for l in (ep/'a11y_requests.jsonl').read_text().splitlines()]
  assert len(reqs)==next(r['model_calls'] for r in rows if r['task']==task)
  assert all(x['images']==0 and all(isinstance(m['content'],str) for m in x['request']['messages']) and x['request']['chat_template_kwargs']['enable_thinking']==False and x['request']['temperature']==0 for x in reqs)
  decisions=[json.loads(l) for l in (ep/'a11y_decisions.jsonl').read_text().splitlines()]
  assert any(not d.get('parse_error') for d in decisions)
  assert all(not d.get('parse_error') or d['parse_error']=='Target element is not visible/enabled' for d in decisions),[d['parse_error'] for d in decisions if d.get('parse_error')]
  if arm=='FULL45':assert meta['exploration_enabled'] and meta['graph_execution_enabled'] and (ep/'windows.jsonl').exists()
for task in ['MarkorCreateNote','NotesIsTodo']:
 a=json.load(open(smoke/'BASE'/task/'p0/meta.json'));b=json.load(open(smoke/'FULL45'/task/'p0/meta.json'));assert a['params']==b['params'] and a['seed']==b['seed'] and a['allocated_model_calls']==b['allocated_model_calls']
(root/'functional_smoke_gate.json').write_text(json.dumps(proof,indent=2))
formal=root/'experiments/trace_reachability_validation/raw/a11y_text/qwen3_8b_a11y_pair_20261101'
assert not formal.exists(),'Formal must be fresh'
subprocess.run(['python3','/tmp/prepare_run.py','full'],check=True);subprocess.run(['python3','/tmp/launch_stage.py','full'],check=True)
(root/'pipeline.status.json').write_text(json.dumps(dict(stage='FORMAL116_LAUNCHED',run=str(formal),smoke=str(smoke),gate='functional_smoke_gate.json; logical failures preserved',pid=os.getpid(),updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2))
print('FORMAL_PAIR_LAUNCHED',flush=True)
